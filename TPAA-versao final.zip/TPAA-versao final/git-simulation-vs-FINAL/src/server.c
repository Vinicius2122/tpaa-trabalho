#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

// Adicionado para o toupper
#include <ctype.h>

// Adicionando a estrutura de aluno
#include "data_structures.h"
#include "git_commands.h"

/* Define a porta do servidor */
#define PORT 4242

/* Tamanho do Buffer */
#define BUFFER_LENGTH 4096



#define TABLE_SIZE 1427

/*
 * Execução principal do programa servidor do protocolo simples
 */
int main(void)
 {

    // Criando uma lista encadeada de alunos
    Branch *branches = NULL;
    Branch *current_branch = NULL;  
    Hash *ha = criaHash(TABLE_SIZE);

    // Inicializando o branch master e criando o primeiro commit
    git_branch(&branches, "master", &current_branch);
    current_branch = branches;
    git_commit(current_branch, "First commit");
    insereHash_EnderAberto(ha, current_branch);


     char vetor[100];

     printf("Abrindo socket do servidor...\n");

    /* Estruturas de soquete do cliente e do servidor */
    struct sockaddr_in client, server;

    /* Descritores de arquivo de cliente e servidor */
    int serverfd, clientfd;

    char buffer[BUFFER_LENGTH];

    while (1)
    {
        printf("---------------------------------------------");
        printf("\nIniciando o Servidor\n");

        /* Cria um soquete IPv4 TCP */
        serverfd = socket(AF_INET, SOCK_STREAM, 0);
        if (serverfd == -1)
        {
            perror("Não foi possível criar o soquete do servidor:");
            return EXIT_FAILURE;
        }
        fprintf(stdout, "Soquete do servidor criado com fd: %d\n", serverfd);

        /* Define as propriedades do soquete do servidor */
        server.sin_family = AF_INET;
        server.sin_port = htons(PORT);
        memset(server.sin_zero, 0x0, 8);

        /* Manipula o erro de porta já em uso */
        int yes = 1;
        if (setsockopt(serverfd, SOL_SOCKET, SO_REUSEADDR,
                       &yes, sizeof(int)) == -1)
        {
            perror("Erro nas opções do soquete:");
            return EXIT_FAILURE;
        }

        /* Associa o soquete a uma porta */
        if (bind(serverfd, (struct sockaddr *)&server, sizeof(server)) == -1)
        {
            perror("Erro ao associar o soquete:");
            return EXIT_FAILURE;
        }

        /* Começa a esperar conexões de clientes */
        if (listen(serverfd, 1) == -1)
        {
            perror("Erro na espera de conexões:");
            return EXIT_FAILURE;
        }
        fprintf(stdout, "Ouvindo na porta %d\n", PORT);

        socklen_t client_len = sizeof(client);
        if ((clientfd = accept(serverfd,
                               (struct sockaddr *)&client, &client_len)) == -1)
        {
            perror("Erro ao aceitar conexão do cliente:");
            return EXIT_FAILURE;
        }

        /* Copia para o buffer a mensagem de boas-vindas */
        strcpy(buffer, "Olá, cliente!\n$\n$\0");

        /* Envia:  OLA CLIENTE */
        if (send(clientfd, buffer, strlen(buffer), 0))
        {
            fprintf(stdout, "Cliente conectado.\nAguardando mensagem do cliente ...");
            fprintf(stdout, "\n\nServer:\n");
            git_log(current_branch);


            /* Comunica com o cliente até receber a mensagem "bye" */
            do
            {
                /* Zera o buffer */
                memset(buffer, 0x0, BUFFER_LENGTH);

                // Receber o comando: (1o recv)
                int received_bytes = recv(clientfd, buffer, BUFFER_LENGTH, 0);

                if (received_bytes == -1)
                {
                    perror("Falha ao receber dados do cliente");
                    break;
                }

                if (received_bytes == 0)
                {
                    // O cliente encerrou a conexão inesperadamente
                    fprintf(stdout, "Cliente desconectado.\n");
                    break;
                }
                if (strcmp(buffer, "exit") == 0)
                {
                    // Mensagem "bye" recebida
                    send(clientfd, "exit", 4, 0);
                }

                printf("---------------------------------------------");
                printf("\n\nPedido: %s\n", buffer);

                if(strcmp(buffer, "Git pull") == 0)
                {


            memset(buffer, 0x0, BUFFER_LENGTH);

            // envia o nome do branch:
            send(clientfd, current_branch->name, BUFFER_LENGTH, 0);
            //recebe ok
            recv(clientfd, buffer, 2, 0);
        
            int aux3 = numCommits(current_branch);
            char aux5[BUFFER_LENGTH];
            sprintf(aux5, "%d", aux3);

            memset(buffer, 0x0, BUFFER_LENGTH);

            //envia o numero de commits:
            send(clientfd, aux5, BUFFER_LENGTH, 0);
            recv(clientfd, buffer, 16, 0);

            // envia os commits:

            Commit *current = current_branch->commits;

            while (current != NULL)
            {    

            memset(buffer, 0x0, BUFFER_LENGTH);
            strcpy(vetor, current->message);
            send(clientfd, vetor, 100, 0);
            recv(clientfd, buffer, 15, 0);
            current = current->next;
            }


            printf("\nBRANCH ENVIADO: %s\n", current_branch->name);
            git_log(current_branch);
            printf("\n\n");
            }


                if(strcmp(buffer, "Git push") == 0){

                    send(clientfd, "Ok", 2, 0);
                                        
                    //branch auxiliar invertido
                    Branch *branches2 = NULL;
                    Branch *current_branch2 = NULL;  
                    Hash *ha2 = criaHash(TABLE_SIZE);

                    //branch auxiliar corrigido
                    Branch *branches3 = NULL;
                    Branch *current_branch3 = NULL;  
                    Hash *ha3 = criaHash(TABLE_SIZE);

                    memset(buffer, 0x0, BUFFER_LENGTH);

                    //recebe o nome do branch: (2o recv)
                    recv(clientfd, buffer, BUFFER_LENGTH, 0);
                    printf("\nNome do branch recebido: %s\n", buffer);
                    char nome_branch[strlen(buffer)];
                    strcpy(nome_branch, buffer);

                    // criando branch auxiliar 1
                    git_branch(&branches2, nome_branch, &current_branch2);
                    current_branch2 = branches2;
                    //criando branch auxiliar 2
                    git_branch(&branches3, nome_branch, &current_branch3);
                    current_branch3 = branches3;

                    //envia que recebeu o branch:
                    send(clientfd, "Branch recebido", 16, 0);

                    // git_branch(&branches, buffer, &current_branch);
                    // git_checkout(&current_branch, &current_commit, branches, buffer, ha);
                    
                    memset(buffer, 0x0, BUFFER_LENGTH);

                    //recebe o numero de commits: (3o recv)
                    recv(clientfd, buffer, BUFFER_LENGTH, 0);
                    printf("Numero de commits recebidos: %s\n", buffer);

                    //envia que recebeu o numero de commits:
                    send(clientfd, "numero de commits recebido", 27, 0);
                    int d = atoi(buffer);

                    memset(buffer, 0x0, BUFFER_LENGTH);

                    //recebe os commits: (4o recv)
                    for(int i = 0; i < d; i++){
                        memset(buffer, 0x0, BUFFER_LENGTH);
                        recv(clientfd, buffer, BUFFER_LENGTH, 0);
                        // printf("Mensagem recebida do cliente: %s\n", buffer);
                        send(clientfd, "commit recebido", 15, 0);
                        git_commit(current_branch2, buffer);
                        insereHash_EnderAberto(ha2, current_branch2);
                        }

                    // printf("\n\n");
                    // git_log(current_branch2);

                    Commit *current_commit2 = current_branch2->commits;
                    printf("\n");
                    while(current_commit2){
                        memset(buffer, 0x0, BUFFER_LENGTH);
                        git_commit(current_branch3, current_commit2->message);

                        insereHash_EnderAberto(ha3, current_branch3);
                        current_commit2 = current_commit2->next;
                    }
                    // printf("\n\n");
                    // git_log(current_branch3);


                    free_branches(branches2);
                    git_merge(current_branch, branches3, nome_branch);

                    // char *vetor9 = (char*) malloc(60 * sizeof(char));
                    // strcpy(vetor9, nome_branch);
                    // printf("\nnome: %s\n", vetor9);
                    // strcpy(current_branch->name, vetor9);

                    // current_branch->name = nome_branch;
                    git_log(current_branch);
                    printf("\n");
                }

            } while (strcmp(buffer, "bye"));
        }

        /* Fecha a conexão do cliente */
        close(clientfd);

        /* Feche o soquete local */
        close(serverfd);

        printf("Conexão fechada\n\n");
    }
    return EXIT_SUCCESS;
}