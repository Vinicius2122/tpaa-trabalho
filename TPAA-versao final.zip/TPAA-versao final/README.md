# Projeto Git Simulation

Este projeto é uma simulação básica do sistema de controle de versão Git, criada para fins educacionais. Inclui  funções básicas como criar commits, criar branches, fazer checkout e mesclar branches.


## Requisitos

- GCC (GNU Compiler Collection)
- Make

## Instalação

1. Clone o repositório para sua máquina local:git clone https://github.com/gcunha-campos/projeto-Tecnicas.git

2. Navegue até a pasta do projeto:
cd projeto-matheus

3. Compile o projeto usando o comando `make`:
make

## Continuação



